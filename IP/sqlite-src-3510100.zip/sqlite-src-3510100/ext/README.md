## Loadable Extensions

Various [loadable extensions](https://sqlite.org/loadext.html) for
SQLite are found in subfolders.

Most subfolders are dedicated to a single loadable extension (for
example FTS5, or RTREE).  But the misc/ subfolder contains a collection
of smaller single-file extensions.
